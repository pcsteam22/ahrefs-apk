(() => {
  if (window.__bulkAhrefs) return;
  window.__bulkAhrefs = true;
  const KIND = location.pathname.includes("website-authority-checker") ? "dr" : "traffic";
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const COUNTRIES = ["Afghanistan","Albania","Algeria","Andorra","Angola","Argentina","Armenia","Australia","Austria","Azerbaijan","Bahamas","Bahrain","Bangladesh","Barbados","Belarus","Belgium","Belize","Benin","Bhutan","Bolivia","Bosnia and Herzegovina","Botswana","Brazil","Brunei","Bulgaria","Burkina Faso","Burundi","Cambodia","Cameroon","Canada","Cape Verde","Chad","Chile","China","Colombia","Congo","Costa Rica","Croatia","Cuba","Cyprus","Czechia","Czech Republic","Denmark","Dominican Republic","Ecuador","Egypt","El Salvador","Estonia","Eswatini","Ethiopia","Fiji","Finland","France","Gabon","Gambia","Georgia","Germany","Ghana","Greece","Guatemala","Guinea","Guyana","Haiti","Honduras","Hong Kong","Hungary","Iceland","India","Indonesia","Iran","Iraq","Ireland","Israel","Italy","Ivory Coast","Jamaica","Japan","Jordan","Kazakhstan","Kenya","Kosovo","Kuwait","Kyrgyzstan","Laos","Latvia","Lebanon","Lesotho","Liberia","Libya","Liechtenstein","Lithuania","Luxembourg","Macao","Madagascar","Malawi","Malaysia","Maldives","Mali","Malta","Mauritania","Mauritius","Mexico","Moldova","Monaco","Mongolia","Montenegro","Morocco","Mozambique","Myanmar","Namibia","Nepal","Netherlands","New Zealand","Nicaragua","Niger","Nigeria","North Macedonia","Norway","Oman","Pakistan","Palestine","Panama","Papua New Guinea","Paraguay","Peru","Philippines","Poland","Portugal","Puerto Rico","Qatar","Romania","Russia","Rwanda","Saudi Arabia","Senegal","Serbia","Singapore","Slovakia","Slovenia","Somalia","South Africa","South Korea","South Sudan","Spain","Sri Lanka","Sudan","Suriname","Sweden","Switzerland","Syria","Taiwan","Tajikistan","Tanzania","Thailand","Togo","Trinidad and Tobago","Tunisia","Turkey","Turkmenistan","Uganda","Ukraine","United Arab Emirates","United Kingdom","United States","Uruguay","Uzbekistan","Venezuela","Vietnam","Yemen","Zambia","Zimbabwe"];

  function candidates(t) {
    const out = [];
    let m;
    if (KIND === "dr") {
      const re = /Domain Rating[^\d]{0,30}(\d{1,3}(?:\.\d+)?)/gi;
      while ((m = re.exec(t))) if (+m[1] <= 100) out.push(m[1]);
    } else {
      const re = /traffic[^\d]{0,40}(\d[\d.,]*\s?[KMB]?)(?![\w])/gi;
      while ((m = re.exec(t))) out.push(m[1].trim());
    }
    return out;
  }

  function parseCountry(t) {
    let best = null;
    const isL = ch => /[A-Za-z]/.test(ch || "");
    for (const name of COUNTRIES) {
      let i = t.indexOf(name);
      while (i !== -1) {
        if (!isL(t[i - 1]) && !isL(t[i + name.length])) {
          const after = t.slice(i + name.length, i + name.length + 40);
          const before = t.slice(Math.max(0, i - 25), i);
          const m = after.match(/^[^\d%]{0,25}?(\d{1,3}(?:[.,]\d+)?)\s*%/) || before.match(/(\d{1,3}(?:\.\d+)?)\s*%[^\d%]{0,12}$/);
          if (m) {
            const p = parseFloat(m[1].replace(",", "."));
            if (p <= 100 && (!best || p > best.pct)) best = { name, pct: p };
          }
        }
        i = t.indexOf(name, i + name.length);
      }
    }
    return best;
  }

  async function waitForInput() {
    for (let i = 0; i < 30; i++) {
      const inp = [...document.querySelectorAll("input")].find(
        x => x.offsetParent && ["text", "url", "search", ""].includes(x.type)
      );
      if (inp) return inp;
      await sleep(500);
    }
    return null;
  }

  function submit(inp) {
    const scope = inp.closest("form") || document;
    const btns = [...scope.querySelectorAll("button,[role=button],input[type=submit]")].filter(b => b.offsetParent && !b.disabled);
    const btn = btns.find(b => /check|analy|submit|get |search|go/i.test(b.textContent || b.value || "")) || btns[0];
    if (btn) btn.click();
    else if (inp.form) inp.form.requestSubmit();
    else inp.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
  }

  const send = o => { try { Bridge.send(JSON.stringify(o)); } catch (e) {} };

  (async () => {
    let job = null;
    try { job = JSON.parse(Bridge.getJob() || "null"); } catch (e) {}
    if (!job || job.kind !== KIND) return;
    const key = "__bulk_" + job.token;
    const already = sessionStorage.getItem(key) === "1";   // page reload hua to dobara submit na karein
    const baseline = already ? [] : candidates(document.body.innerText);
    const baseCountry = already ? null : parseCountry(document.body.innerText);
    const startedAt = Date.now();
    let asked = false;
    if (!already) {
      const inp = await waitForInput();
      if (inp) {
        Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set.call(inp, job.domain);
        inp.dispatchEvent(new Event("input", { bubbles: true }));
        inp.dispatchEvent(new Event("change", { bubbles: true }));
        await sleep(1200);
        sessionStorage.setItem(key, "1");
        submit(inp);
      }
    }
    const dom = job.domain.toLowerCase();
    for (let i = 0; i < 300; i++) {
      await sleep(1000);
      if (!asked && Date.now() - startedAt > 20000) { asked = true; send({ type: "attention", token: job.token }); }
      const t = document.body.innerText;
      if (t.toLowerCase().includes(dom)) {
        const c = candidates(t).filter(x => !baseline.includes(x));
        if (c.length) {
          let country = "";
          if (KIND === "traffic") {
            window.scrollTo(0, document.body.scrollHeight);
            for (let k = 0; k < 10; k++) {
              const cc = parseCountry(document.body.innerText);
              if (cc && !(baseCountry && baseCountry.name === cc.name && baseCountry.pct === cc.pct)) { country = cc.name; break; }
              await sleep(1000);
            }
          }
          send({ type: "result", token: job.token, value: c[0], country });
          return;
        }
      }
    }
    const t = document.body.innerText;
    const k = t.search(KIND === "dr" ? /Domain Rating/i : /traffic/i);
    send({ type: "result", token: job.token, failed: true, snippet: t.slice(Math.max(0, k), Math.max(0, k) + 300).replace(/\s+/g, " ") });
  })();
})();
