package com.ahrefs.bulk;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {

    private LinearLayout root;
    private WebView panel;   // upar: apna control panel (assets/panel.html)
    private WebView site;    // neeche: Ahrefs ka page (captcha yahin solve karein)
    private LinearLayout.LayoutParams panelLp, siteLp;
    private volatile String job = "";
    private String injectJs = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            injectJs = readAsset("inject.js");
        } catch (IOException e) {
            injectJs = "";
        }

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        panel = new WebView(this);
        site = new WebView(this);
        panelLp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 2f);
        siteLp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        root.addView(panel, panelLp);
        root.addView(site, siteLp);
        setContentView(root);

        setupPanel();
        setupSite();
        panel.loadUrl("file:///android_asset/panel.html");
    }

    private void setupPanel() {
        WebSettings s = panel.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        panel.addJavascriptInterface(new Native(), "Native");
        panel.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("OK", (d, w) -> result.confirm())
                        .setOnCancelListener(d -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("OK", (d, w) -> result.confirm())
                        .setNegativeButton("Cancel", (d, w) -> result.cancel())
                        .setOnCancelListener(d -> result.cancel())
                        .show();
                return true;
            }
        });
    }

    private void setupSite() {
        WebSettings s = site.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setUserAgentString(s.getUserAgentString().replace("; wv", ""));
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(site, true);
        site.addJavascriptInterface(new Bridge(), "Bridge");
        site.setWebChromeClient(new WebChromeClient());
        site.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                if (url != null && url.contains("ahrefs.com") && !injectJs.isEmpty()) {
                    view.evaluateJavascript(injectJs, null);
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String scheme = u.getScheme();
                String host = u.getHost();
                boolean web = "http".equals(scheme) || "https".equals(scheme);
                // sirf ahrefs.com ke andar navigation allow
                return web && (host == null || !host.endsWith("ahrefs.com"));
            }
        });
    }

    private String readAsset(String name) throws IOException {
        try (InputStream in = getAssets().open(name);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        }
    }

    @Override
    public void onBackPressed() {
        // back dabane se queue band na ho, app bas peeche chali jaye
        moveTaskToBack(true);
    }

    // ===== Panel (trusted, local file) -> Java =====
    private class Native {
        @JavascriptInterface
        public void loadSite(final String url) {
            runOnUiThread(() -> site.loadUrl(url));
        }

        @JavascriptInterface
        public void setJob(String j) {
            job = j == null ? "" : j;
        }

        @JavascriptInterface
        public void keepAwake(final boolean on) {
            runOnUiThread(() -> {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }

        @JavascriptInterface
        public void layout(final boolean siteBig) {
            runOnUiThread(() -> {
                panelLp.weight = siteBig ? 1f : 2f;
                siteLp.weight = siteBig ? 3f : 1f;
                panel.setLayoutParams(panelLp);
                site.setLayoutParams(siteLp);
                root.requestLayout();
            });
        }

        @JavascriptInterface
        public void toast(final String m) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, m, Toast.LENGTH_LONG).show());
        }

        @JavascriptInterface
        public void saveFile(String name, String b64, String mime) {
            try {
                byte[] data = Base64.decode(b64, Base64.DEFAULT);
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                v.put(MediaStore.Downloads.MIME_TYPE, mime);
                v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) throw new IOException("insert failed");
                try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                    os.write(data);
                }
                toast("Saved in Downloads: " + name);
            } catch (Exception e) {
                toast("Save failed: " + e);
            }
        }
    }

    // ===== Ahrefs page ki injected script -> Java =====
    private class Bridge {
        @JavascriptInterface
        public String getJob() {
            return job;
        }

        @JavascriptInterface
        public void send(String json) {
            // json ko string literal bana kar bhejte hain, taake page se code panel mein na chal sake
            final String js = "window.onSite&&window.onSite(JSON.parse(" + JSONObject.quote(json) + "))";
            runOnUiThread(() -> panel.evaluateJavascript(js, null));
        }
    }
}
